from django.shortcuts import render, HttpResponse
def index(request):
    return HttpResponse("response from index method from root route, localhost:8000!")

    urlpatterns = [
    path('bears', views.one_method),                       
        path('bears/<int:my_val>', views.another_method),       
        path('bears/<str:name>/poke', views.yet_another),       
    	path('<int:id>/<str:color>', views.one_more),   
]